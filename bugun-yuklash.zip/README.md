# BUGUN — bugungi kichik qadam

Bepul statik sayt: HTML + CSS + JavaScript. Server, baza va pullik xizmat kerak emas.
Progress foydalanuvchining o‘z qurilmasida saqlanadi (Profil → "Ma’lumotlarni saqlash" orqali zaxira olish mumkin).

## Fayllar
- `index.html`, `styles.css`, `app.js` — sayt
- `tasks.json` — vazifalar va mini-test savollari (yangi vazifa qo‘shish uchun shu faylni tahrirlang)
- `manifest.json`, `service-worker.js`, ikonka rasmlari — telefonga o‘rnatish va offline rejim

## GitHub Pages'ga joylash
1. GitHub'da yangi **public** repository yarating.
2. Shu papka ICHIDAGI hamma narsani repository'ning asosiga (root) yuklang: `index.html` root'da bo‘lsin, 4 ta ikonka rasmi (`icon-*.png`, `apple-touch-icon.png`) ham root’da bo‘lsin.
3. **Settings → Pages** → **Deploy from a branch** → branch `main`, papka `/(root)` → **Save**.
4. 1–2 daqiqadan keyin GitHub bergan HTTPS manzilni oching.

## Yangilash
Fayllarni o‘zgartirib qayta yuklasangiz bo‘ldi. Yangi fayl qo‘shsangiz yoki ro‘yxatni o‘zgartirsangiz, `service-worker.js` ichidagi `CACHE_NAME` raqamini oshiring (`bugun-v5` → `bugun-v6`).

## Telefonga o‘rnatish
Saytni HTTPS manzilda oching va brauzer menyusidan "Bosh ekranga qo‘shish" / "Ilovani o‘rnatish" ni tanlang.

## Eslatma
- Service worker faqat HTTPS (yoki localhost) da ishlaydi. GitHub Pages HTTPS beradi.
- Statistika (GoatCounter) va Telegram eslatma hozircha qo‘shilmagan.
