(() => {
  'use strict';

  const KEY = 'bugun-v3';
  const LEGACY_KEYS = ['bugun-v2', 'bugun-v1'];
  const goals = {
    english: { icon: '🇬🇧', name: 'Ingliz tili', desc: 'Har kuni kichik til mashqi.' },
    money: { icon: '💰', name: 'Pul', desc: 'Moliyaviy tartib va ongli qarorlar.' }
  };
  const timeOptions = [5, 15, 30, 60];
  const defaultState = {
    goal: null, minutes: null, todayTaskId: null, todayTaskDate: null, completed: {}, completedDays: {},
    taskHistory: [], streak: 0, lastDate: null, theme: 'light', name: '', startedAt: null,
    forgivenessWeek: null, eveningAnswers: {}, quizResults: {}, quizLastDate: null, quizLastCount: null
  };
  let taskData = { uz: { english: [], money: [] }, quiz: { english: [], money: [] } };
  let state = load();
  const main = document.querySelector('#main');
  const toast = document.querySelector('#toast');
  const modal = document.querySelector('#modal');
  const fileInput = document.querySelector('#restore-file');

  function localDateKey(date = new Date()) {
    const y = date.getFullYear(); const m = String(date.getMonth() + 1).padStart(2, '0'); const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const todayKey = () => localDateKey();
  function dateFromKey(key) { const [y,m,d] = key.split('-').map(Number); return new Date(y,m-1,d); }
  function yesterdayKey() { const d = new Date(); d.setDate(d.getDate()-1); return localDateKey(d); }
  function daysAgoKey(n) { const d = new Date(); d.setDate(d.getDate()-n); return localDateKey(d); }
  function weekKey(key = todayKey()) { const d = dateFromKey(key); const day = d.getDay() || 7; d.setDate(d.getDate() - day + 1); return localDateKey(d); }
  function dayDiff(a,b) { return Math.round((dateFromKey(b)-dateFromKey(a))/86400000); }

  function normalizeState(saved) {
    return {
      ...defaultState, ...saved,
      completed: saved.completed && typeof saved.completed === 'object' ? saved.completed : {},
      completedDays: saved.completedDays && typeof saved.completedDays === 'object' ? saved.completedDays : {},
      taskHistory: Array.isArray(saved.taskHistory) ? saved.taskHistory : [],
      eveningAnswers: saved.eveningAnswers && typeof saved.eveningAnswers === 'object' ? saved.eveningAnswers : {},
      quizResults: saved.quizResults && typeof saved.quizResults === 'object' ? saved.quizResults : {},
      name: typeof saved.name === 'string' ? saved.name : '',
      minutes: timeOptions.includes(Number(saved.minutes)) ? Number(saved.minutes) : null,
      startedAt: typeof saved.startedAt === 'string' ? saved.startedAt : null,
      forgivenessWeek: typeof saved.forgivenessWeek === 'string' ? saved.forgivenessWeek : null,
      todayTaskDate: typeof saved.todayTaskDate === 'string' ? saved.todayTaskDate : null,
      quizLastCount: Number.isInteger(saved.quizLastCount) ? saved.quizLastCount : null
    };
  }
  function load() {
    try {
      let raw = localStorage.getItem(KEY); let migrated = false;
      if (!raw) {
        for (const k of LEGACY_KEYS) { raw = localStorage.getItem(k); if (raw) { migrated = true; break; } }
      }
      const saved = raw ? JSON.parse(raw) : {};
      const normalized = normalizeState(saved);
      if (migrated) setTimeout(save, 0);
      return normalized;
    } catch (error) {
      console.warn('Bugun: load failed, defaults used.', error);
      return normalizeState({});
    }
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); return true; }
    catch (error) { console.warn('Bugun: save failed.', error); showToast('Ma’lumotni saqlab bo‘lmadi. Brauzer xotirasini tekshiring.'); return false; }
  }
  function escapeHTML(s) { return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function avatarLetter() { const name = String(state.name || '').trim(); return escapeHTML(Array.from(name)[0]?.toUpperCase() || '?'); }
  function completedCount() { return Object.keys(state.completedDays).length; }
  function userDayNumber() { if (!state.startedAt) return 1; return Math.max(1, dayDiff(state.startedAt, todayKey()) + 1); }
  function todayDone() { return Boolean(state.completedDays[todayKey()]); }
  function taskPool(goal, minutes) { return taskData.uz?.[goal]?.filter(t => Number(t.minutes) === Number(minutes)) || []; }
  function recentTaskIds(goal, days = 7) {
    const cutoff = new Set(Array.from({length:days},(_,i)=>daysAgoKey(i)));
    return new Set(state.taskHistory.filter(x=>x.goal===goal && cutoff.has(x.date)).map(x=>x.taskId));
  }
  function chooseTask(goal, minutes) {
    const pool = taskPool(goal, minutes); if (!pool.length) return null;
    const recent = recentTaskIds(goal,7);
    const eligible = pool.filter(t => !t.requiresDay || userDayNumber() >= t.requiresDay);
    const fresh = eligible.filter(t => !recent.has(t.id));
    const candidates = fresh.length ? fresh : eligible.length ? eligible : pool;
    const seed = Math.floor(Date.now()/86400000) + completedCount() + candidates.length;
    return candidates[seed % candidates.length];
  }
  function getTaskById(id) {
    if (!id) return null;
    for (const goal of Object.keys(goals)) { const found = taskData.uz?.[goal]?.find(t=>t.id===id); if(found) return found; }
    return null;
  }
  function ensureTodayTask() {
    if (!state.goal || !state.minutes) return null;
    if (todayDone()) return getTaskById(state.completedDays[todayKey()]) || getTaskById(state.todayTaskId);
    if (state.todayTaskId && state.todayTaskDate===todayKey()) { const existing=getTaskById(state.todayTaskId); if(existing && existing.goal===state.goal && Number(existing.minutes)===Number(state.minutes)) return existing; }
    const task=chooseTask(state.goal,state.minutes); if(task){state.todayTaskId=task.id;state.todayTaskDate=todayKey();save();} return task;
  }

  // Phase 3: one forgiveness day per calendar week. It is used only when calculating a live streak.
  function currentStreak() {
    const today = todayKey();
    const cursor = dateFromKey(today);
    // Today may still be unfinished: that does not break the streak.
    if (!state.completedDays[today]) cursor.setDate(cursor.getDate() - 1);
    let count = 0, lastWasSkip = false;
    const skippedWeeks = new Set();
    for (let i = 0; i < 400; i++) {
      const key = localDateKey(cursor);
      if (state.completedDays[key]) { count++; lastWasSkip = false; }
      else {
        const wk = weekKey(key);
        // one forgiven day per calendar week, and never two missed days in a row
        if (lastWasSkip || skippedWeeks.has(wk)) break;
        skippedWeeks.add(wk); lastWasSkip = true;
      }
      cursor.setDate(cursor.getDate() - 1);
    }
    return count;
  }
  function progress() {
    const count=completedCount(); const cycleCount=count===0?0:((count-1)%30)+1;
    return {count,cycleCount,pct:count===0?0:Math.min(100,(cycleCount/30)*100)};
  }
  function recentHistory(days=7) { const keys=new Set(Array.from({length:days},(_,i)=>daysAgoKey(i))); return state.taskHistory.filter(x=>keys.has(x.date)); }
  function weeklySummary() {
    const history=recentHistory(7); const days=new Set(history.map(x=>x.date)); const minutes=history.reduce((s,x)=>s+Number(x.minutes||0),0);
    const byGoal={}; history.forEach(x=>byGoal[x.goal]=(byGoal[x.goal]||0)+Number(x.minutes||0));
    const top=Object.entries(byGoal).sort((a,b)=>b[1]-a[1])[0];
    return {days:days.size, minutes, topGoal:top ? goals[top[0]].name : '—', history};
  }
  function returnMessage() {
    if (!state.lastDate) return '';
    const gap=dayDiff(state.lastDate,todayKey());
    if (gap >= 2) return 'Qaytganingiz yaxshi, bugun 5 daqiqalik yengil qadamdan boshlaymiz.';
    return '';
  }
  function quizDue() { const c = completedCount(); return c > 0 && c % 7 === 0 && state.quizLastCount !== c; }

  function setNav(name){document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.nav===name));}
  function render(){
    document.documentElement.dataset.theme=state.theme==='dark'?'dark':'';
    const route=location.hash.replace('#','')||'home';
    if(route==='plan')renderPlan(); else if(route==='progress')renderProgress(); else if(route==='profile')renderProfile(); else renderHome();
    setNav(route); updateHeaderAvatar();
  }
  function updateHeaderAvatar(){const a=document.querySelector('.topbar .avatar');if(a)a.textContent=avatarLetter();}
  function renderHome(){
    const task=todayDone()?getTaskById(state.completedDays[todayKey()]):ensureTodayTask(); const p=progress(); const streak=currentStreak(); const returning=returnMessage();
    main.innerHTML=`
      <section class="hero"><div class="eyebrow">Bugungi kichik qadam</div><h1>Bugun o‘zing uchun nima qilasan?</h1><p>Katta maqsadni hozir bajarish mumkin bo‘lgan kichik qadamga aylantir.</p></section>
      ${returning?`<section class="return-card card"><strong>👋 ${escapeHTML(returning)}</strong></section>`:''}
      ${quizDue()?`<section class="quiz-banner card"><div><b>🧠 7 kunlik mini-test</b><small>3 ta savol. Bugungi qadamdan keyin bilimingizni sinab ko‘ring.</small></div><button class="secondary-btn" data-action="quiz">Boshlash</button></section>`:''}
      ${!state.goal||!state.minutes?`<button class="primary-btn full" data-action="start">Menga bugungi qadamni ber →</button>`:`<section class="today card"><div class="task-top"><span class="task-badge">${goals[state.goal].icon} ${goals[state.goal].name}</span><span class="pill">${state.minutes} daqiqa</span></div>${task?`<h3>${escapeHTML(task.title)}</h3><p>${escapeHTML(task.text)}</p>`:'<h3>Bugungi qadam tayyorlanmoqda…</h3>'}<div class="meta"><span class="pill">Bugungi qadam</span><span class="pill">${streak?`🔥 ${streak} kun`:'Birinchi kun'}</span></div>${todayDone()?'<button class="secondary-btn full" disabled>✓ Bugun bajarildi</button>':task?'<button class="primary-btn full" data-action="complete">Bajardim ✓</button>':''}</section>`}
      <div class="section-head"><h2>Yo‘nalish</h2><button class="change-btn" data-action="start">O‘zgartirish</button></div>
      <section class="quick">${Object.entries(goals).map(([id,g])=>`<button class="goal card ${state.goal===id?'selected-goal':''}" data-goal="${id}"><span class="goal-icon">${g.icon}</span><span><strong>${g.name}</strong><small>${g.desc}</small></span></button>`).join('')}</section>
      <section class="progress-card card"><div class="streak"><div><small>Hozirgi streak</small><strong>🔥 ${streak} kun</strong></div><div style="text-align:right"><small>Bajarilgan qadamlar</small><strong>${p.count}</strong></div></div></section>
      <section class="evening-card card"><div><b>🌙 Kechqurun o‘zingizdan so‘rang</b><small>Bugun nima o‘rgandingiz?</small></div><button class="ghost-btn" data-action="evening">Javob berish</button></section>`;
  }
  function renderPlan(){
    const days=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(6-i));const key=localDateKey(d),id=state.completedDays[key],task=getTaskById(id),done=Boolean(id);return `<div class="week-day ${done?'done':''} ${key===todayKey()?'today-day':''}"><span>${escapeHTML(d.toLocaleDateString('uz-UZ',{weekday:'short'}))}</span><strong>${d.getDate()}</strong><small>${escapeHTML(d.toLocaleDateString('uz-UZ',{month:'short'}))}</small><b>${done?'✓':'·'}</b><em>${task?escapeHTML(goals[task.goal].name):''}</em></div>`}).join('');
    const summary=weeklySummary(); const task=todayDone()?getTaskById(state.completedDays[todayKey()]):ensureTodayTask();
    main.innerHTML=`<div class="eyebrow">Haftalik ko‘rinish</div><h1 class="page-title">Rejang</h1><p class="sub">Oxirgi 7 kun. Kichik qadamlar yig‘ilib, yo‘lga aylanadi.</p><section class="week-grid card">${days}</section><section class="summary-grid"><div class="stat card"><b>${summary.days}/7</b><span>faol kun</span></div><div class="stat card"><b>${summary.minutes} daq</b><span>ajratilgan vaqt</span></div><div class="stat card"><b>${escapeHTML(summary.topGoal)}</b><span>eng ko‘p yo‘nalish</span></div></section>${task?`<section class="card today"><span class="task-badge">${goals[task.goal].icon} ${goals[task.goal].name}</span><h3>${escapeHTML(task.title)}</h3><p>${escapeHTML(task.text)}</p><span class="pill">⏱ ${task.minutes} daqiqa · ${todayDone()?'Bajarilgan':'Bugun'}</span><div style="height:14px"></div>${todayDone()?'<button class="secondary-btn full" disabled>✓ Bugun bajarildi</button>':'<button class="primary-btn full" data-action="complete">Bajardim ✓</button>'}</section>`:`<section class="card empty"><p>Bugungi qadamni olish uchun yo‘nalish va vaqt tanlang.</p><button class="primary-btn" data-action="start">Boshlash</button></section>`}`;
  }
  function renderProgress(){
    const p=progress(), streak=currentStreak(), summary=weeklySummary();
    main.innerHTML=`<div class="eyebrow">Natijang</div><h1 class="page-title">Sekin, lekin oldinga.</h1><p class="sub">Har bir bajarilgan kichik qadam hisoblanadi.</p><div class="stat-grid"><div class="stat card"><b>🔥 ${streak}</b><span>kunlik streak</span></div><div class="stat card"><b>${p.count}</b><span>bajarilgan qadam</span></div><div class="stat card"><b>${p.cycleCount}/30</b><span>30 kunlik yo‘l</span></div><div class="stat card"><b>${Math.round(p.pct)}%</b><span>joriy sikl</span></div></div><section class="progress-card card"><div class="progress-row"><span>30 kunlik yo‘l</span><span>${p.cycleCount}/30</span></div><div class="bar"><i style="width:${p.pct}%"></i></div><p class="sub" style="margin:14px 0 0">Maqsad mukammallik emas. Bugun kechagidan bir qadam oldinda bo‘lish.</p></section><div class="section-head"><h2>Haftalik xulosa</h2></div><section class="summary-grid"><div class="stat card"><b>${summary.days}</b><span>kun bajarildi</span></div><div class="stat card"><b>${summary.minutes}</b><span>daqiqa ajratildi</span></div><div class="stat card wide"><b>${escapeHTML(summary.topGoal)}</b><span>ko‘proq vaqt ketgan yo‘nalish</span></div></section>${quizDue()?`<section class="quiz-banner card"><div><b>🧠 Mini-test vaqti</b><small>7 kunlik bosqichni 3 ta savol bilan yakunlang.</small></div><button class="secondary-btn" data-action="quiz">Boshlash</button></section>`:''}`;
  }
  function renderProfile(){
    const name=String(state.name||'').trim();
    main.innerHTML=`<div class="eyebrow">Profil</div><section class="profile-head card"><div class="profile-big">${avatarLetter()}</div><div><h2 style="margin:0">${escapeHTML(name||'Mehmon')}</h2><p class="sub" style="margin:2px 0 0">Bugundan boshladik.</p></div></section><div class="settings card"><button class="setting" data-action="name"><span><b>Ism</b><small>${escapeHTML(name||'Ism kiritilmagan')}</small></span><span>›</span></button><button class="setting" data-action="toggle-theme"><span><b>Ko‘rinish</b><small>${state.theme==='dark'?'Tungi':'Yorug‘'} rejim</small></span><span>◐</span></button><button class="setting" data-action="backup"><span><b>Ma’lumotlarni saqlash</b><small>Telefon almashtirsangiz ham progressni olib o‘ting</small></span><span>↓</span></button><button class="setting" data-action="restore"><span><b>Ma’lumotlarni yuklash</b><small>Oldin saqlangan faylni qaytaring</small></span><span>↑</span></button><button class="setting" data-action="reset"><span><b>Ma’lumotlarni tozalash</b><small>Progressni boshidan boshlash</small></span><span>›</span></button></div>`;
  }

  function openStartModal(goalOverride=null,minutesOverride=null){
    const selectedGoal=goalOverride||state.goal||'english', selectedMinutes=Number(minutesOverride||state.minutes||15);
    modal.innerHTML=`<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="start-title"><h2 id="start-title">Bugun nimani yaxshilamoqchisan?</h2><p>Avval yo‘nalishni, keyin bugun ajrata oladigan vaqtingni tanla.</p><div class="modal-step"><b>1 · Yo‘nalish</b><div class="choice-grid compact">${Object.entries(goals).map(([id,g])=>`<button class="choice ${selectedGoal===id?'selected':''}" data-pick-goal="${id}"><strong>${g.icon} ${g.name}</strong><small>${g.desc}</small></button>`).join('')}</div></div><div class="modal-step"><b>2 · Bugun qancha vaqting bor?</b><div class="time-grid">${timeOptions.map(m=>`<button class="time-choice ${selectedMinutes===m?'selected':''}" data-pick-time="${m}">${m}<small>daqiqa</small></button>`).join('')}</div></div>${todayDone()?'<div class="notice">✓ Bugungi qadam allaqachon bajarilgan. Tanlovingiz ertangi qadam uchun saqlanadi.</div>':''}<button class="primary-btn full" data-action="confirm-start">${todayDone()?'Ertangi qadamni sozlash →':'Bugungi qadamni ber →'}</button><button class="ghost-btn full" data-action="close-modal">Hozir emas</button></div>`;
    modal.dataset.selectedGoal=selectedGoal;modal.dataset.selectedMinutes=String(selectedMinutes);modal.classList.add('open');modal.setAttribute('aria-hidden','false');modal.querySelector('[data-pick-goal].selected')?.focus();
  }
  function closeModal(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');}
  function showToast(msg){toast.textContent=msg;toast.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove('show'),2500);}
  function confirmStart(){
    const goal=modal.dataset.selectedGoal, minutes=Number(modal.dataset.selectedMinutes); if(!goals[goal]||!timeOptions.includes(minutes))return;
    const changed=state.goal!==goal||Number(state.minutes)!==minutes; state.goal=goal;state.minutes=minutes;
    if(!state.startedAt)state.startedAt=todayKey(); if(changed&&!todayDone()){state.todayTaskId=null;state.todayTaskDate=null;} save();closeModal();render();showToast(todayDone()?'Ertangi qadam uchun saqlandi!':'Bugungi qadam tayyor!');
  }
  function completeTask(){
    if(todayDone()){showToast('Bugungi qadam allaqachon bajarilgan. Ertaga yangi qadam bor.');render();return;}
    const task=ensureTodayTask(); if(!task){openStartModal();return;} const today=todayKey();
    state.completed[task.id]=Date.now(); state.completedDays[today]=task.id;
    state.taskHistory=[...state.taskHistory.filter(x=>x.date!==today),{date:today,taskId:task.id,goal:task.goal,minutes:task.minutes}].slice(-180);
    const yesterday=yesterdayKey(); if(state.lastDate===yesterday)state.streak=(state.streak||0)+1; else if(state.lastDate!==today)state.streak=1; state.lastDate=today;state.todayTaskId=task.id;state.todayTaskDate=today;save();render();showToast('Bugungi qadam bajarildi! 🎉');
  }
  function openEvening(){
    const key=todayKey(), old=state.eveningAnswers[key]||'';
    modal.innerHTML=`<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="evening-title"><h2 id="evening-title">Bugun nima o‘rgandingiz?</h2><p>Bir jumla kifoya. Bu javob faqat sizning qurilmangizda saqlanadi.</p><textarea id="evening-input" class="text-input" rows="5" maxlength="500" placeholder="Bugun men…">${escapeHTML(old)}</textarea><button class="primary-btn full" data-action="save-evening">Saqlash</button><button class="ghost-btn full" data-action="close-modal">Hozir emas</button></div>`;
    modal.classList.add('open');modal.setAttribute('aria-hidden','false');setTimeout(()=>document.querySelector('#evening-input')?.focus(),30);
  }
  function saveEvening(){const input=document.querySelector('#evening-input');if(!input)return;state.eveningAnswers[todayKey()]=input.value.trim().slice(0,500);save();closeModal();showToast('Javobingiz saqlandi. 🌙');}
  function quizQuestions(){
    const all=taskData.quiz?.[state.goal]||[]; if(all.length<3)return [];
    const seed=(completedCount()+todayKey().split('-').join('')).toString().split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    return [0,1,2].map((_,i)=>all[(seed+i*7)%all.length]);
  }
  function openQuiz(){
    const qs=quizQuestions(); if(qs.length<3){showToast('Mini-test hozircha tayyor emas.');return;}
    modal.innerHTML=`<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="quiz-title"><h2 id="quiz-title">🧠 7 kunlik mini-test</h2><p>3 ta savol. Eng yaxshi natija — xatodan qo‘rqmasdan javob berish.</p>${qs.map((q,i)=>`<div class="quiz-q"><b>${i+1}. ${escapeHTML(q.question)}</b><div class="quiz-options">${q.options.map((o,j)=>`<button class="quiz-option" data-q="${i}" data-a="${j}">${escapeHTML(o)}</button>`).join('')}</div></div>`).join('')}<button class="primary-btn full" data-action="finish-quiz">Natijani ko‘rish</button><button class="ghost-btn full" data-action="close-modal">Hozir emas</button></div>`;
    modal._quizQuestions=qs;modal.classList.add('open');modal.setAttribute('aria-hidden','false');
  }
  function finishQuiz(){
    const qs=modal._quizQuestions||[];let score=0;const answers=[];
    qs.forEach((q,i)=>{const selected=modal.querySelector(`.quiz-option[data-q="${i}"].selected`);const a=selected?Number(selected.dataset.a):-1;answers.push(a);if(a===q.answer)score++;});
    if(answers.includes(-1)){showToast('Avval 3 ta savolga ham javob bering.');return;}
    const result={date:todayKey(),score,total:qs.length};state.quizResults[todayKey()]=result;state.quizLastDate=todayKey();state.quizLastCount=completedCount();save();
    modal.innerHTML=`<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="quiz-result"><h2 id="quiz-result">${score===3?'🎉 Ajoyib!':score>=2?'👏 Yaxshi natija!':'🌱 Davom etamiz!'}</h2><p>Siz <strong>${score}/${qs.length}</strong> ta savolga to‘g‘ri javob berdingiz.</p><div class="result-note">Har 7 kun — kichik tekshiruv. Maqsad mukammallik emas, o‘sishni ko‘rish.</div><button class="primary-btn full" data-action="close-modal">Davom etish</button></div>`;
  }
  function downloadBackup(){
    const payload={app:'Bugun',version:3,exportedAt:new Date().toISOString(),state}; const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`bugun-backup-${todayKey()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('Zaxira fayli tayyor.');
  }
  function restoreBackup(file){
    const reader=new FileReader();reader.onload=()=>{try{const data=JSON.parse(reader.result);const incoming=data.state||data;if(!incoming||typeof incoming!=='object')throw new Error('invalid');state=normalizeState(incoming);save();render();showToast('Ma’lumotlar qayta tiklandi.');}catch(e){showToast('Faylni o‘qib bo‘lmadi. To‘g‘ri backup faylini tanlang.');}};reader.readAsText(file);
  }

  document.addEventListener('click',e=>{
    const nav=e.target.closest('[data-nav]');if(nav){location.hash=nav.dataset.nav;return;}
    const goal=e.target.closest('[data-goal]');if(goal){openStartModal(goal.dataset.goal,state.minutes||15);return;}
    const pickGoal=e.target.closest('[data-pick-goal]');if(pickGoal){modal.querySelectorAll('[data-pick-goal]').forEach(x=>x.classList.remove('selected'));pickGoal.classList.add('selected');modal.dataset.selectedGoal=pickGoal.dataset.pickGoal;return;}
    const pickTime=e.target.closest('[data-pick-time]');if(pickTime){modal.querySelectorAll('[data-pick-time]').forEach(x=>x.classList.remove('selected'));pickTime.classList.add('selected');modal.dataset.selectedMinutes=pickTime.dataset.pickTime;return;}
    const quizOpt=e.target.closest('.quiz-option');if(quizOpt){modal.querySelectorAll(`.quiz-option[data-q="${quizOpt.dataset.q}"]`).forEach(x=>x.classList.remove('selected'));quizOpt.classList.add('selected');return;}
    const action=e.target.closest('[data-action]');if(!action)return;const a=action.dataset.action;
    if(a==='home')location.hash='home'; if(a==='start')openStartModal(); if(a==='close-modal')closeModal(); if(a==='complete')completeTask(); if(a==='confirm-start')confirmStart();
    if(a==='quiz')openQuiz(); if(a==='finish-quiz')finishQuiz(); if(a==='evening')openEvening(); if(a==='save-evening')saveEvening();
    if(a==='toggle-theme'){state.theme=state.theme==='dark'?'light':'dark';save();render();}
    if(a==='profile')location.hash='profile';
    if(a==='name'){const n=prompt('Ismingiz:',state.name||'');if(n!==null){state.name=n.trim().slice(0,30);save();render();}}
    if(a==='backup')downloadBackup(); if(a==='restore')fileInput?.click();
    if(a==='reset'&&confirm('Barcha progressni tozalaysizmi?')){state=normalizeState({});save();render();showToast('Progress tozalandi');}
  });
  modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))closeModal();});
  fileInput?.addEventListener('change',e=>{const file=e.target.files?.[0];if(file)restoreBackup(file);e.target.value='';});
  window.addEventListener('hashchange',render);
  fetch('tasks.json',{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error(`tasks.json ${r.status}`);return r.json();}).then(data=>{taskData=data;render();}).catch(error=>{console.error('Bugun: tasks.json yuklanmadi.',error);showToast('Vazifalar fayli yuklanmadi. Sayt fayllarini birga joylang.');render();});
  render();
})();
